
    Game Title: Epic Forest Fire of Mystery

  Team Members: jaburns, mrhale, salted, Nicolas Samoil, Brian Taylor

   Description: Fire Guy is trying to discover Water Girl's secret hideouts in the
                forest by torching it to the ground.  Water Girl is not enthused.

   How to Play: The game is played using two XBox 360 controls.  Left stick moves
                the player, and the A button uses the character's power.
                If Fire Guy uncovers four secret hideouts before the time is up,
                then Fire Guy wins.  If Water Girl prevents this for long enough
                that her timer elapses, then Water Girl wins.

		Keyboard Alternatives. P1: WASD E to fire, P2: IJKL O to fire

        Themes: fire: The forest is being set on fire.
                forest: The game takes place in a forest.
                mystery: Neither player knows where the hide-outs are.
                secret hideout: The goal of the game is to either uncover
                                or prevent the discovery of secret hideouts.
                epic: The music and explosions are epic.

 Donations Met: mrhale, salted

